SPARSE BNN VERIFICATION SUITE — COLAB RUN INSTRUCTIONS
=====================================================

Files:
  sbnn_verification_colab.py

Fast default run
----------------
1. Open Google Colab.
2. Upload sbnn_verification_colab.py.
3. Run:

   %run /content/sbnn_verification_colab.py

The script will:
  * run a sparse nonlinear binary-classification simulation;
  * run a sparse right-censored survival simulation;
  * run leakage-resistant nested/outer-CV verification on sklearn WDBC;
  * compare against Gaussian BNN, elastic-net logistic regression, random forest,
    Gaussian-prior Bayesian survival NN, and ridge Cox where appropriate;
  * print/display every numerical table and every plot inline;
  * save all CSV/PNG/JSON outputs under /content/sbnn_verification_outputs;
  * create /content/sbnn_verification_outputs.zip.

At the end, use:

   from google.colab import files
   files.download('/content/sbnn_verification_outputs.zip')

Optional NKI analysis
---------------------
Upload the VERIFIED cleaned NKI file and edit the configuration block near the top:

   NKI_FILE = '/content/your_nki_file.xlsx'
   NKI_TIME_COL = 'exact_followup_time_column'
   NKI_EVENT_COL = 'exact_event_column'   # must represent 1=event, 0=censored
   NKI_DROP_COLS = ['ID']                  # optional

Then rerun the script. The NKI module refuses to invent endpoint coding when the columns
cannot be uniquely and safely identified.

Publication-size run
--------------------
Change:
   FAST_MODE = False

This increases epochs, Monte Carlo posterior draws, outer/inner folds, and bootstrap
replications. Use FAST_MODE=True first to verify data coding and pipeline execution.

Important interpretation
------------------------
The software does NOT force the proposed model to beat every benchmark. It reports
all discrimination, proper-scoring-rule, calibration, PIP, stability, and uncertainty
results as obtained. Mixed benchmark results should be reported truthfully.
